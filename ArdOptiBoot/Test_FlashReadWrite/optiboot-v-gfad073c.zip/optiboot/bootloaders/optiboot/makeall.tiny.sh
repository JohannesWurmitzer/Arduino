make attiny1634at12 $*
make attiny1634at16 $*
make attiny1634at8 $*
make attiny1634at8_5v $*
make attiny1634at737 $*
make attiny1634at921 $*
make attiny1634at110 $*
make attiny1634at147 $*

make attiny1634at12ser1 $*
make attiny1634at16ser1 $*
make attiny1634at8ser1 $*
make attiny1634at8_5vser1 $*
make attiny1634at737ser1 $*
make attiny1634at921ser1 $*
make attiny1634at110ser1 $*
make attiny1634at147ser1 $*


make attiny841 $*
make attiny841at184 $*
make attiny841at147 $*
make attiny841at110 $*
make attiny841at921 $*
make attiny841at737 $*
make attiny841at20 $*
make attiny841at16 $*
make attiny841at12 $*
make attiny841at8 $*
make attiny841at8_5v $*

make attiny841at184ser1 $*
make attiny841at147ser1 $*
make attiny841at110ser1 $*
make attiny841at921ser1 $*
make attiny841at737ser1 $*
make attiny841at20ser1 $*
make attiny841at16ser1 $*
make attiny841at12ser1 $*
make attiny841at8ser1 $*

make attiny841at20noLED $*
make attiny841at16noLED $*
make attiny841at8noLED $*

make attiny828at8 $*
